﻿using UnityEngine;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using UnityEngine.UI;

public class LoadDataFromXml : MonoBehaviour 
{

	public string fileName = "data.xml";

	public Vector3 mBallCenter,mPipeCenter,mPipeAxis;

	public float mBallRadius,mPipeLength,mPipeInnerRadius,mPipeOuterRadius;

	public GameObject mSphereObject;

	public GameObject mCylinderObject;

	XmlNodeList  mNodeList;

	public Text mText;

	public void ReadXml()
	{		
		string path = Application.streamingAssetsPath+"/"+fileName;

		print("path "+path);

		XmlDocument xmlDoc = new XmlDocument();

		if(File.Exists(path))
		{
			xmlDoc.Load(path);

			mNodeList = xmlDoc.GetElementsByTagName("ball");

			foreach (XmlNode BallNode in mNodeList)		
			{				
				XmlNodeList ballData= BallNode.ChildNodes;

				foreach (XmlNode items in ballData) 
				{	
					if(items.Name == "center")
					{
						XmlNodeList ballCenter= items.ChildNodes;

						foreach (XmlNode item in ballCenter)
						{
							if(item.Name=="x")
								mBallCenter.x =float.Parse(item.InnerText);

							if(item.Name=="y")
								mBallCenter.y =float.Parse(item.InnerText);

							if(item.Name=="z")
								mBallCenter.z =float.Parse(item.InnerText);
						}
					}
					if(items.Name == "radius")
						mBallRadius = float.Parse(items.InnerText);
				}
			}

			mNodeList = xmlDoc.GetElementsByTagName("pipe");

			foreach (XmlNode pipeNode in mNodeList)		
			{				
				XmlNodeList pipeData= pipeNode.ChildNodes;

				foreach (XmlNode items in pipeData) 
				{	
					if(items.Name == "center")
					{
						XmlNodeList pipeCenter= items.ChildNodes;

						foreach (XmlNode item in pipeCenter)
						{
							if(item.Name=="x")
								mPipeCenter.x =float.Parse(item.InnerText);

							if(item.Name=="y")
								mPipeCenter.y =float.Parse(item.InnerText);

							if(item.Name=="z")
								mPipeCenter.z =float.Parse(item.InnerText);
						}
					}
					if(items.Name == "axis")
					{
						XmlNodeList pipeAxis = items.ChildNodes;

						foreach (XmlNode item in pipeAxis)
						{
							if(item.Name=="x")
								mPipeAxis.x =float.Parse(item.InnerText);

							if(item.Name=="y")
								mPipeAxis.y =float.Parse(item.InnerText);

							if(item.Name=="z")
								mPipeAxis.z =float.Parse(item.InnerText);
						}
					}
					if(items.Name == "length")
						mPipeLength = float.Parse(items.InnerText);
					if(items.Name == "innerRadius")
						mPipeInnerRadius = float.Parse(items.InnerText);
					if(items.Name == "outerRadius")
						mPipeOuterRadius = float.Parse(items.InnerText);
				}
			}
		}
		else
		{
			Debug.LogError("File not found!");

			mText.text = path;
		}

		SetProperties();
	}

	void SetProperties()
	{
		mSphereObject.transform.localPosition = mBallCenter;

		mSphereObject.transform.localScale = Vector3.one * mBallRadius;

		mCylinderObject.transform.localPosition =mPipeCenter;

		mCylinderObject.transform.localEulerAngles = mPipeAxis;

		mCylinderObject.transform.localScale = Vector3.one * mPipeLength;

		mText.text = "Inner Radius: "+mPipeInnerRadius+" Outer Radius: "+mPipeOuterRadius;
	}
}

